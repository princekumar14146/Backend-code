package com.demo.Backend.poc.demo.Entity;

import com.demo.Backend.poc.demo.Enums.PlanStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "plan")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Plan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String planName;

    private Double speed;

    private LocalDateTime startTime;

    @Enumerated(EnumType.STRING)
    private PlanStatus status;

    @OneToMany(
            mappedBy = "plan",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    private List<RoutePoint> routePoints;
}
