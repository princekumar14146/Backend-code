package com.demo.Backend.poc.demo.Service;

import com.demo.Backend.poc.demo.Dto.CreatePlanRequest;
import com.demo.Backend.poc.demo.Dto.PlanResponse;

public interface PlanService {

    PlanResponse createPlan(CreatePlanRequest request);
}
