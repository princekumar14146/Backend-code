package com.demo.Backend.poc.demo.Service;

public interface SimulationService {

    void startSimulation();

    void stopSimulation();
}
