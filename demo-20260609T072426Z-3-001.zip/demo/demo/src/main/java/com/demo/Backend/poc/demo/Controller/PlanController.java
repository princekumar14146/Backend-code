package com.demo.Backend.poc.demo.Controller;

import com.demo.Backend.poc.demo.Dto.CreatePlanRequest;
import com.demo.Backend.poc.demo.Dto.PlanResponse;
import com.demo.Backend.poc.demo.Service.PlanService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/plans")
@RequiredArgsConstructor
public class PlanController {

    private final PlanService planService;

    @PostMapping
    public PlanResponse createPlan(
            @RequestBody CreatePlanRequest request) {

        return planService.createPlan(request);
    }
}
