package com.demo.Backend.poc.demo.Repositories;

import com.demo.Backend.poc.demo.Entity.Plan;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PlanRepository extends JpaRepository<Plan, Long>{

}
