package com.demo.Backend.poc.demo.Scheduler;

import com.demo.Backend.poc.demo.Entity.RoutePoint;
import com.demo.Backend.poc.demo.Entity.Vehicle;
import com.demo.Backend.poc.demo.Repositories.RoutePointRepository;
import com.demo.Backend.poc.demo.Repositories.VehicleRepository;
import com.demo.Backend.poc.demo.ServiceImpl.SimulationStateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class VehicleMovementScheduler {

    private final VehicleRepository vehicleRepository;

    private final RoutePointRepository routePointRepository;

    private final SimulationStateService stateService;

    @Scheduled(fixedRate = 1000)
    public void moveVehicles() {

        if(!stateService.isRunning()) {
            return;
        }

        List<Vehicle> vehicles =
                vehicleRepository
                        .findBySimulationStartedTrue();

        for(Vehicle vehicle : vehicles) {

            moveVehicle(vehicle);
        }
    }

    private void moveVehicle(
            Vehicle vehicle) {

        if(vehicle.getFuelRemaining() <= 0) {

            vehicle.setSimulationStarted(false);

            vehicleRepository.save(vehicle);

            return;
        }

        List<RoutePoint> points =
                routePointRepository
                        .findByPlanIdOrderBySequenceNo(
                                vehicle.getCurrentPlanId());

        int index =
                vehicle.getCurrentPointIndex();

        if(index >= points.size()) {

            vehicle.setSimulationStarted(false);

            vehicleRepository.save(vehicle);

            return;
        }

        RoutePoint point =
                points.get(index);

        vehicle.setCurrentLatitude(
                point.getLatitude());

        vehicle.setCurrentLongitude(
                point.getLongitude());

        vehicle.setCurrentPointIndex(
                index + 1);

        vehicle.setFuelRemaining(
                vehicle.getFuelRemaining()
                        - (1.0 / 60.0));

        vehicleRepository.save(vehicle);

        log.info(
                "{} -> Lat={} Lon={} Fuel={}",
                vehicle.getVehicleName(),
                point.getLatitude(),
                point.getLongitude(),
                vehicle.getFuelRemaining());
    }
}
