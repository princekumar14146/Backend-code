package com.demo.Backend.poc.demo.ServiceImpl;

import lombok.Getter;
import org.springframework.stereotype.Service;

@Getter
@Service
public class SimulationStateService {

    private volatile boolean running = false;

    public void start() {
        running = true;
    }

    public void stop() {
        running = false;
    }

    public boolean isRunning() {
        return running;
    }

}
