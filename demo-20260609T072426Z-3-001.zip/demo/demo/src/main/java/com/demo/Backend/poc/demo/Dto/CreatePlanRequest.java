package com.demo.Backend.poc.demo.Dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class CreatePlanRequest {

    private String planName;

    private Double speed;

    private LocalDateTime startTime;

    private List<CoordinateDto> routePoints;
}
