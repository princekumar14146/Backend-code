package com.demo.Backend.poc.demo.Repositories;

import com.demo.Backend.poc.demo.Entity.RoutePoint;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RoutePointRepository extends JpaRepository<RoutePoint, Long> {
    List<RoutePoint> findByPlanIdOrderBySequenceNo(Long planId);
}
