package com.demo.Backend.poc.demo.Dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class PlanResponse {

    private Long planId;

    private String planName;

    private Double speed;

    private LocalDateTime startTime;
}
