package com.demo.Backend.poc.demo.Entity;

import com.demo.Backend.poc.demo.Enums.VehicleType;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "vehicle")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String vehicleName;

    @Enumerated(EnumType.STRING)
    private VehicleType vehicleType;

    private Double fuelCapacity;

    private Double fuelRemaining;

    private Double currentLatitude;

    private Double currentLongitude;

    @Column(name = "current_route_index")
    private Integer currentRouteIndex;

    @Column(name = "simulation_started")
    private Boolean simulationStarted;

    @Column(name = "current_plan_id")
    private Long currentPlanId;

    @Column(name = "current_point_index")
    private Integer currentPointIndex;
}
