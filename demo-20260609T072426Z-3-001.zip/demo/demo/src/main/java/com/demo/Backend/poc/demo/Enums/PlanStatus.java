package com.demo.Backend.poc.demo.Enums;

public enum PlanStatus {

    CREATED,
    RUNNING,
    COMPLETED,
    STOPPED
}
