package com.demo.Backend.poc.demo.Dto;

import lombok.Data;

@Data
public class CoordinateDto {

    private Double latitude;
    private Double longitude;
}
