package com.demo.Backend.poc.demo.Enums;

public enum SimulationMode {

    EVENT_BASED,
    TIME_BASED
}
