package com.demo.Backend.poc.demo.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "route_point")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RoutePoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer sequenceNo;

    private Double latitude;

    private Double longitude;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plan_id")
    private Plan plan;
}
