package com.demo.Backend.poc.demo.Repositories;

import com.demo.Backend.poc.demo.Entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VehicleRepository extends JpaRepository<Vehicle, Long>{

    List<Vehicle> findBySimulationStartedTrue();
}
