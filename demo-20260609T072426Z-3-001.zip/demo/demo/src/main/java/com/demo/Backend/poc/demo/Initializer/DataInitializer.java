package com.demo.Backend.poc.demo.Initializer;

import com.demo.Backend.poc.demo.Entity.Vehicle;
import com.demo.Backend.poc.demo.Enums.VehicleType;
import com.demo.Backend.poc.demo.Repositories.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final VehicleRepository vehicleRepository;

    @Override
    public void run(String... args) {

        if(vehicleRepository.count() > 0) {
            return;
        }

        vehicleRepository.save(
                Vehicle.builder()
                        .vehicleName("ARMY_VEHICLE")
                        .vehicleType(
                                VehicleType.ARMY_VEHICLE)
                        .fuelCapacity(1000.0)
                        .fuelRemaining(1000.0)
                        .build());

        vehicleRepository.save(
                Vehicle.builder()
                        .vehicleName("TANK")
                        .vehicleType(
                                VehicleType.TANK)
                        .fuelCapacity(1000.0)
                        .fuelRemaining(1000.0)
                        .build());

        vehicleRepository.save(
                Vehicle.builder()
                        .vehicleName("TRUCK")
                        .vehicleType(
                                VehicleType.TRUCK)
                        .fuelCapacity(1000.0)
                        .fuelRemaining(1000.0)
                        .build());
    }
}
