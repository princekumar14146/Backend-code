package com.demo.Backend.poc.demo.Controller;

import com.demo.Backend.poc.demo.Service.SimulationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/simulation")
@RequiredArgsConstructor
public class SimulationController {

    private final SimulationService simulationService;

    @PostMapping("/start")
    public String start() {

        simulationService.startSimulation();

        return "Simulation Started";
    }

    @PostMapping("/stop")
    public String stop() {

        simulationService.stopSimulation();

        return "Simulation Stopped";
    }
}
