package com.demo.Backend.poc.demo.Entity;

import com.demo.Backend.poc.demo.Enums.PlanStatus;
import com.demo.Backend.poc.demo.Enums.SimulationMode;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "simulation")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Simulation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private SimulationMode simulationMode;

    private LocalDateTime simulationStartTime;

    private LocalDateTime simulationEndTime;

    @Enumerated(EnumType.STRING)
    private PlanStatus status;
}
