package com.demo.Backend.poc.demo.ServiceImpl;

import com.demo.Backend.poc.demo.Dto.CoordinateDto;
import com.demo.Backend.poc.demo.Dto.CreatePlanRequest;
import com.demo.Backend.poc.demo.Dto.PlanResponse;
import com.demo.Backend.poc.demo.Entity.Plan;
import com.demo.Backend.poc.demo.Entity.RoutePoint;
import com.demo.Backend.poc.demo.Enums.PlanStatus;
import com.demo.Backend.poc.demo.Exception.BadRequestException;
import com.demo.Backend.poc.demo.Repositories.PlanRepository;
import com.demo.Backend.poc.demo.Service.PlanService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PlanServiceImpl implements PlanService {

    private final PlanRepository planRepository;

    @Override
    @Transactional
    public PlanResponse createPlan(
            CreatePlanRequest request) {

        validateRequest(request);

        Plan plan = Plan.builder()
                .planName(request.getPlanName())
                .speed(request.getSpeed())
                .startTime(request.getStartTime())
                .status(PlanStatus.CREATED)
                .build();

        List<RoutePoint> routePoints = new ArrayList<>();

        int sequence = 1;

        for (CoordinateDto point : request.getRoutePoints()) {

            RoutePoint routePoint = RoutePoint.builder()
                    .sequenceNo(sequence++)
                    .latitude(point.getLatitude())
                    .longitude(point.getLongitude())
                    .plan(plan)
                    .build();

            routePoints.add(routePoint);
        }

        plan.setRoutePoints(routePoints);

        Plan savedPlan = planRepository.save(plan);

        return PlanResponse.builder()
                .planId(savedPlan.getId())
                .planName(savedPlan.getPlanName())
                .speed(savedPlan.getSpeed())
                .startTime(savedPlan.getStartTime())
                .build();
    }

    private void validateRequest(
            CreatePlanRequest request) {

        if (request.getPlanName() == null ||
                request.getPlanName().isBlank()) {

            throw new BadRequestException(
                    "Plan Name is mandatory");
        }

        if (request.getSpeed() == null ||
                request.getSpeed() <= 0) {

            throw new BadRequestException(
                    "Speed must be greater than 0");
        }

        if (request.getStartTime() == null) {

            throw new BadRequestException(
                    "Start Time is mandatory");
        }

        if (request.getRoutePoints() == null ||
                request.getRoutePoints().size() < 7) {

            throw new BadRequestException(
                    "Minimum 7 route points required");
        }
    }
}
