package com.demo.Backend.poc.demo.ServiceImpl;

import com.demo.Backend.poc.demo.Entity.Plan;
import com.demo.Backend.poc.demo.Entity.Vehicle;
import com.demo.Backend.poc.demo.Repositories.PlanRepository;
import com.demo.Backend.poc.demo.Repositories.VehicleRepository;
import com.demo.Backend.poc.demo.Service.SimulationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SimulationServiceImpl implements SimulationService {

    private final VehicleRepository vehicleRepository;

    private final PlanRepository planRepository;

    private final SimulationStateService stateService;

    @Override
    public void startSimulation() {

        List<Plan> plans =
                planRepository.findAll();

        List<Vehicle> vehicles =
                vehicleRepository.findAll();

        int count =
                Math.min(plans.size(),
                        vehicles.size());

        for(int i=0;i<count;i++) {

            Vehicle vehicle =
                    vehicles.get(i);

            Plan plan =
                    plans.get(i);

            vehicle.setCurrentPlanId(
                    plan.getId());

            vehicle.setCurrentPointIndex(0);

            vehicle.setSimulationStarted(true);

            vehicleRepository.save(vehicle);
        }

        stateService.start();
    }

    @Override
    public void stopSimulation() {

        stateService.stop();

        List<Vehicle> vehicles =
                vehicleRepository.findAll();

        for(Vehicle vehicle : vehicles) {

            vehicle.setSimulationStarted(false);

            vehicleRepository.save(vehicle);
        }
    }
}
