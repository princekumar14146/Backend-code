package com.demo.Backend.poc.demo.Enums;

public enum VehicleType {

    ARMY_VEHICLE,
    TANK,
    TRUCK
}
