package com.demo.Backend.poc.demo.Repositories;

import com.demo.Backend.poc.demo.Entity.Simulation;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SimulationRepository extends JpaRepository<Simulation, Long>{

}
